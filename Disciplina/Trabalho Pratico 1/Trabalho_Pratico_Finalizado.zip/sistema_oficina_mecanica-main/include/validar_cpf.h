#ifndef VALIDARCPF_H
#define VALIDARCPF_h

int validarcpf(int cpf[11]);

int ler_cpf(char *entrada);

#endif